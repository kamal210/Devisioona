﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanToDecimal
{
    class Program
    {
        static void Main(string[] args)
        {


            // value to store the final result
            int result = 0;

            //instance of ValidatorClass
            Validator vdc = new Validator();

            Console.WriteLine("Input a Roman Number!!");
            string roman = Console.ReadLine();

            //Call the ValidCharacter method to check required validatoin rule.
            bool validator = vdc.ValidCharacter(roman);

            //IF the validation is true then call the DataConversion method to do necessary conversion from Roman to Decimal
            
            if (validator == true)
                result = vdc.DataConversion(roman);
            else
            {
                Console.WriteLine("Invalid Roman Number!!");
                Console.ReadKey();

            }

            //If the return value is greater than 0 then prints the equivalent decimal digit else prints
            //There is an invalid roman number.
            if (result > 0)
            {
                Console.WriteLine("The equivalent Decimal is {0}", result);
                Console.ReadKey();

            }


            else if (result < 0)

            {
                Console.WriteLine("Invalid Roman Number!!");
                Console.ReadKey();

            }




        }
    }
}
