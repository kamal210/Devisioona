﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanToDecimal
{
    class Validator
    {
        char[] romanList = { 'I', 'V', 'X', 'L', 'C', 'D', 'M' };
        int[] decimalValues = { 1, 5, 10, 50, 100, 500, 1000 };


        public bool ValidCharacter(string _roman)

        {
            //Checks if the input string's character  are valid  Roman alphabets
            foreach (char c in _roman)
            {
                if (!romanList.Contains(c))
                {
                    return false;
                }


            }

            //Checks V,L and D Rule: if the input string has more once V,L or D is present
            if ((_roman.Count(x => x == 'V') > 1) || (_roman.Count(x => x == 'L') > 1) || (_roman.Count(x => x == 'D') > 1))
            {

                return false;
            }



            //Checks if the input string more than three same character

            var result = from c in _roman.ToCharArray()
                         group c by c into m
                         select new { Key = m.Key, Count = m.Count() };
            foreach (var item in result)
            {

                if (item.Count > 3)
                    return false;

            }

            return true;
        }



        //Converts the Roman character to respective decimal digit and store in the arraylist.
        public int DataConversion(string _roman)
        {
            int totalDecimal = 0;
            int maxNum = 1000;// dummy digit to store the subtracted value

            ArrayList values = new ArrayList();
            for (int i = 0; i < _roman.Length; i++)
            {

                // Getting base value based upon the respective roman character 
                //comparing its index position with the decimalValues Array.
                int decimalValue = decimalValues[IndexValue(_roman[i])];

                //checking if the subtracted value exceed or match the curretn value
                if (decimalValue > maxNum)
                    return -1;

                int nextDecimalValue = 0;
                if (i < (_roman.Length - 1))
                {
                    nextDecimalValue = decimalValues[IndexValue(_roman[i + 1])];
                    //Comparing if the nextvalue from the left to right is smaller
                    //if it is then check the validation whether it is subtracted, so it must have I or X or C then
                    //it also validates the value being subtracted is one tenth of the second character or not. 


                    if (nextDecimalValue > decimalValue)
                    {
                        if ("IXC".IndexOf(_roman[i]) == -1 || nextDecimalValue > (decimalValue * 10))
                            return -1;// invalid data
                        else
                        {
                            //to ensure no further number match or exceeds the subtracted value
                            maxNum = decimalValue - 1;

                            //subtraction of two number is done and stored in integer decimalValue 
                            decimalValue = nextDecimalValue - decimalValue;
                            i++;
                        }



                    }
                }

                values.Add(decimalValue);


            }

            totalDecimal = CheckValues(values);
            return totalDecimal;

        }


        //gets the  index value of repective roman character from the array  romanList 
        int IndexValue(char c)
        {

            for (int index = 0; index < 7; index++)
            {
                if (romanList[index] == c)
                    return index;

            }
            return -1;// invalid data
        }


        //Check through the iteration, if the value in the arraylist are on ascending order from Left to Right
        //if it is then do the summation on the list of values is done.

        int CheckValues(ArrayList _values)
        {
            int total = 0;
            for (int i = 0; i < _values.Count - 1; i++)
            {
                if ((int)_values[i] < (int)_values[i + 1])
                    return -1; // invalid data


            }
            foreach (int num in _values)
            {

                total = total + num;
            }
            return total;
        }

    }
}
